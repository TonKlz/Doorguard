/**
 * Door / Window Guard — micro:bit V2 firmware
 * ==============================================================
 *
 * HOW IT DECIDES
 * ---------------
 *   magnetic force (µT) <  500  ->  magnet gone   ->  OPEN -> alarm
 *   magnetic force (µT) >= 500  ->  magnet there  ->  CLOSED
 *
 * With no magnet nearby you read about 50 (the Earth's own field).
 * With the magnet against the back of the board you should read
 * thousands. 500 sits comfortably between the two.
 *
 * WHAT YOU SEE WHEN IT STARTS
 * ----------------------------
 *   1. One beep     -> running, speaker works
 *   2. Bluetooth on -> the phone app can connect
 *   3. Checkmark    -> closed / armed.   X -> open / alarming.
 *
 * NOTE: the first time it reads the sensor, the micro:bit may run its
 * built-in compass calibration (tilt the board until all 25 LEDs fill).
 * That's a one-time thing. Bluetooth and the buttons are started BEFORE
 * that point on purpose, so the app keeps working either way.
 * Keep the magnet well away while calibrating.
 *
 * BUTTONS
 * --------
 *   Button A - show the live magnetic force reading
 *   Button B - silence the siren while it's sounding
 *
 * BLUETOOTH PROTOCOL (matches the web app)
 * -----------------------------------------
 *   micro:bit -> phone: ARMED / ALARM_TRIGGERED / DOOR_OPEN / DOOR_CLOSED /
 *                       BYPASS_ACTIVE:<secs> / BYPASSED:<mins> / SILENCED
 *   phone -> micro:bit: STATUS / BYPASS:<mins> / BYPASS:0
 */

// ---------- The one number to tune ----------
let THRESHOLD = 500

// ---------- State ----------
let doorOpen = false
let bypassUntil = 0      // 0 = not bypassed, otherwise a runningTime() stamp
let alarmOn = false
let bleReady = false

function isBypassed (): boolean {
    return bypassUntil != 0 && input.runningTime() < bypassUntil
}

function send (line: string) {
    if (bleReady) bluetooth.uartWriteString(line + "\n")
}

function sendStatus () {
    send(doorOpen ? "DOOR_OPEN" : "DOOR_CLOSED")
    if (alarmOn) {
        send("ALARM_TRIGGERED")
    } else if (isBypassed()) {
        send("BYPASS_ACTIVE:" + Math.idiv(bypassUntil - input.runningTime(), 1000))
    } else {
        send("ARMED")
    }
}

function updateIcon () {
    if (alarmOn) {
        basic.showIcon(IconNames.No)
    } else if (isBypassed()) {
        basic.showLeds(`
            . # . # .
            . # . # .
            . # . # .
            . # . # .
            . # . # .
            `)
    } else {
        basic.showIcon(IconNames.Yes)
    }
}

// =====================================================================
// Bluetooth and buttons first, so nothing below can ever lock them out.
// =====================================================================

music.playTone(880, 300)

bluetooth.startUartService()

bluetooth.onBluetoothConnected(function () {
    bleReady = true
    sendStatus()
})

bluetooth.onBluetoothDisconnected(function () {
    bleReady = false
})

bluetooth.onUartDataReceived(serial.delimiters(Delimiters.NewLine), function () {
    let cmd = bluetooth.uartReadUntil(serial.delimiters(Delimiters.NewLine)).trim()
    if (cmd == "STATUS") {
        sendStatus()
    } else if (cmd.substr(0, 7) == "BYPASS:") {
        let mins = parseInt(cmd.substr(7))
        if (mins > 0) {
            bypassUntil = input.runningTime() + mins * 60000
            alarmOn = false
            music.stopAllSounds()
            send("BYPASSED:" + mins)
            send("BYPASS_ACTIVE:" + mins * 60)
        } else {
            bypassUntil = 0
            if (doorOpen) {
                alarmOn = true
                send("ALARM_TRIGGERED")
            } else {
                send("ARMED")
            }
        }
        updateIcon()
    }
})

input.onButtonPressed(Button.A, function () {
    basic.showNumber(input.magneticForce(Dimension.Strength))
    updateIcon()
})

input.onButtonPressed(Button.B, function () {
    if (alarmOn) {
        alarmOn = false
        music.stopAllSounds()
        send("SILENCED")
        if (!doorOpen) send("ARMED")
        updateIcon()
    }
})

// Siren — own fiber, silent unless alarmOn.
basic.forever(function () {
    if (alarmOn) {
        music.playTone(1500, music.beat(BeatFraction.Sixteenth))
        music.playTone(1000, music.beat(BeatFraction.Sixteenth))
    } else {
        basic.pause(100)
    }
})

// Bypass expiry / countdown heartbeat.
loops.everyInterval(1000, function () {
    if (bypassUntil != 0 && input.runningTime() >= bypassUntil) {
        bypassUntil = 0
        if (doorOpen) {
            alarmOn = true
            send("ALARM_TRIGGERED")
        } else {
            send("ARMED")
        }
        updateIcon()
    } else if (isBypassed()) {
        send("BYPASS_ACTIVE:" + Math.idiv(bypassUntil - input.runningTime(), 1000))
    }
})

// =====================================================================
// Main loop.
// =====================================================================

basic.forever(function () {
    if (input.magneticForce(Dimension.Strength) < THRESHOLD) {
        // Magnet gone — door/window is open.
        if (!doorOpen) {
            doorOpen = true
            send("DOOR_OPEN")
            if (!isBypassed()) {
                alarmOn = true
                send("ALARM_TRIGGERED")
            }
            updateIcon()
        }
    } else {
        // Magnet there — door/window is closed.
        if (doorOpen) {
            doorOpen = false
            send("DOOR_CLOSED")
            if (alarmOn) {
                alarmOn = false
                music.stopAllSounds()
                if (!isBypassed()) send("ARMED")
            }
            updateIcon()
        }
    }

    basic.pause(200)
})
