# Door & Window Guard

A micro:bit-based door/window sensor and a phone web app to monitor it and
temporarily bypass it — no extra sensor hardware, just a magnet.

## How it works

- The micro:bit mounts on the door/window **frame**. A small magnet mounts on
  the **door or window itself**, lined up close to the back of the micro:bit.
- The micro:bit's built-in compass chip doubles as a magnetometer. With the
  magnet a few millimetres away, it reads a strong field; when the door opens
  and the magnet moves away, the reading drops. The firmware watches for that
  drop to detect "open".
- While **armed**, an open door/window sounds the onboard buzzer and pushes an
  alert (sound + vibration + notification) to your phone via Bluetooth.
- **Bypass** lets you open the door/window for a set time (e.g. to air out a
  room, or step outside) without triggering the alarm. It re-arms
  automatically when the timer runs out — if the door is still open at that
  point, the alarm sounds immediately.

## What's in this folder

```
alarm-panel-app/          the web app (PWA) — open on your phone
firmware/microbit-door-guard.js   the micro:bit program
README.md                 this file
```

## 1. Flash the micro:bit

1. Go to https://makecode.microbit.org and start a new project.
2. Click the gear icon → **Extensions**, search for `bluetooth`, and add it.
3. Switch the editor to **JavaScript** (toggle top-right) and replace the
   sample code with the contents of
   [`firmware/microbit-door-guard.js`](firmware/microbit-door-guard.js).
4. **Important — this is not the default.** Click the gear icon →
   **Project Settings** and turn **ON**:

   > **Bluetooth: No Pairing Required — Anyone can connect via Bluetooth**

   MakeCode ships with *JustWorks pairing* enabled, which makes the UART
   characteristics require an encrypted, bonded connection. The failure is
   nasty because the app still appears to connect: `startNotifications()`
   fails with **NotSupportedError**, and bypass commands are silently
   rejected, so the micro:bit never reacts to anything you tap.
5. Download the `.hex` file and drag it onto the `MICROBIT` USB drive.

## 2. Mount the hardware

1. Stick the micro:bit to the door/window **frame**, battery pack attached
   (2×AAA is fine; it sleeps between samples so battery life is good).
2. Stick a small, reasonably strong magnet to the **door/window** itself,
   positioned as close as possible to the middle of the back of the
   micro:bit when the door/window is closed (a few mm gap is ideal — test
   and adjust if it's not triggering reliably).
3. **Power on the micro:bit.** It beeps once (that confirms the program is
   running and the speaker works), starts Bluetooth, then shows a
   checkmark (closed/armed) or an X (open/alarming).

### How it decides open vs closed

```
magnetic force (µT) <  500  ->  magnet gone   ->  OPEN -> alarm
magnetic force (µT) >= 500  ->  magnet there  ->  CLOSED
```

`THRESHOLD` is a single number at the top of the firmware, set to **500**
by default. Readings are in microteslas: with no magnet nearby you'll see
about **50** (the Earth's own field), and with the magnet against the back
of the board, thousands. 500 sits comfortably between the two.

### Tuning it

Press **button A** at any time to see the live reading:

1. Door/window **closed**, magnet in place → note the number.
2. Door/window **open**, magnet away → note that number too.
3. Set `let THRESHOLD = 500` at the top of the firmware to roughly halfway
   between them, then re-flash.

If those two numbers come out nearly the same, the magnet is too far away
or too weak — move it flat against the **back** of the micro:bit, as close
as the surfaces allow.

> The first time it reads the sensor, the micro:bit may run its built-in
> compass calibration — tilt the board until all 25 LEDs fill in. That's a
> one-time thing, and Bluetooth plus the buttons are started *before* that
> point so the app keeps working regardless. Keep the magnet well away
> while calibrating.

### On-unit controls
- **Button A** — shows the live magnet reading.
- **Button B** — silences the siren while it's sounding (the phone still
  shows the alarm until the door/window closes).

### If it isn't detecting anything
Press **button A** and compare the number with the door closed vs open. If
the two are close together, the magnet is too far away or too weak — that's
the whole problem. If they're far apart but it still doesn't trigger, your
`THRESHOLD` isn't between them.

## 3. Host and open the web app

Web Bluetooth requires a secure context (HTTPS, or `localhost`). The easiest
free option:

1. Push the `alarm-panel-app/` folder to a GitHub repo and enable
   **GitHub Pages** for it (Settings → Pages → deploy from that folder/branch).
2. Open the resulting `https://…github.io/...` URL on your phone (Chrome/Edge
   on Android, or **Bluefy** on iOS — iOS Safari itself doesn't support Web
   Bluetooth).
3. Tap **Share → Add to Home Screen** (or the browser's install prompt) to
   use it as a standalone app.
4. Tap **Connect to micro:bit**, pick your device from the browser's pairing
   list, and grant Bluetooth + notification permissions when asked.

For local testing on a laptop, you can instead run a static server from this
folder (`npx serve alarm-panel-app`) and open `http://localhost:<port>` —
localhost also counts as a secure context.

## Bluetooth protocol reference

| Direction | Message | Meaning |
|---|---|---|
| micro:bit → phone | `ARMED` | Armed, door/window closed |
| micro:bit → phone | `ALARM_TRIGGERED` | Armed and just opened |
| micro:bit → phone | `DOOR_OPEN` / `DOOR_CLOSED` | Raw sensor state, sent on every change |
| micro:bit → phone | `BYPASS_ACTIVE:<secs>` | Bypass running, seconds left |
| micro:bit → phone | `BYPASSED:<mins>` | Bypass request acknowledged |
| micro:bit → phone | `SILENCED` | Siren muted at the unit |
| phone → micro:bit | `STATUS` | Request a fresh status snapshot |
| phone → micro:bit | `BYPASS:<mins>` | Start a bypass for `<mins>` minutes |
| phone → micro:bit | `BYPASS:0` | Cancel bypass, re-arm now |
